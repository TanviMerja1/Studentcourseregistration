using Microsoft.AspNetCore.Mvc;
using StudentCourseRegistration.Models;

namespace StudentCourseRegistration.Controllers
{
    public class StudentController : Controller
    {
        // In-memory storage (no database needed for this activity)
        private static readonly List<Student> _students = new()
        {
            new Student { Id = 1, Name = "Riya Patel", Email = "riya.patel@example.com", Course = "B.Tech Computer Engineering", Semester = 5 },
            new Student { Id = 2, Name = "Amit Shah",  Email = "amit.shah@example.com",  Course = "B.Tech Information Technology", Semester = 3 }
        };
        private static int _nextId = 3;

        // GET: /Student  or  /Student/Index  -> list of all students
        public IActionResult Index()
        {
            return View(_students);          // data passed Controller -> View
        }

        // GET: /Student/Create -> show empty form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Student/Create -> model binding fills the Student object
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student student)
        {
            // Custom rule: email must be unique
            if (_students.Any(s => s.Email.Equals(student.Email, StringComparison.OrdinalIgnoreCase)))
            {
                ModelState.AddModelError("Email", "This email is already registered.");
            }

            if (!ModelState.IsValid)
            {
                // invalid -> redisplay the same form with error messages
                return View(student);
            }

            student.Id = _nextId++;
            _students.Add(student);

            TempData["Success"] = $"{student.Name} was registered successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: /Student/Details/5
        public IActionResult Details(int id)
        {
            var student = _students.FirstOrDefault(s => s.Id == id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }
    }
}
